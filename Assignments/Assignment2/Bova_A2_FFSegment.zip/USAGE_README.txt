HOW TO USE:
I added a cool GUI that lets the user select the image and Foreground/Background points.

requirements: python 3.9+, numpy, PIL, matplotlib, glob, TKinter

TO RUN:
python ImageSegment_runthis.py

if you want to run just a simple example:
python simple_imagesegment.py